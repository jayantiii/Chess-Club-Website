// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyBKnGjXT6FDqqkf39UVYgx5q89fZE_NYns",
    authDomain: "educhess-ab46e.firebaseapp.com",
    projectId: "educhess-ab46e",
    storageBucket: "educhess-ab46e.appspot.com",
    messagingSenderId: "387520426981",
    appId: "1:387520426981:web:976a2aadf979e22301f50c",
    measurementId: "G-7XBGDVHCDT"
  };